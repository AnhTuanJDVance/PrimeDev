import java.util.HashMap;

public class Script {
    public int removeDuplicates(int[] nums) {
        int re = 1;
        int left = 0;
        int dem = 1;
        for (int i = 1; i < nums.length; i++) {
            if (nums[left] != nums[i]) {
                left = i;
                re++;
                nums[dem] = nums[i];
                dem++;
            }
        }
        return re;
    }
}