import sys
import importlib
import ast

def smart_parse(arg):
    try:
        return ast.literal_eval(arg)
    except:
        return arg

if len(sys.argv) < 2:
    print("Usage: func_name [args...]")
    sys.exit(1)

func_name = sys.argv[1]
args = [smart_parse(arg) for arg in sys.argv[2:]]

# Import sẵn module script
import script
func = getattr(script, func_name)

result = func(*args)
print(result)
