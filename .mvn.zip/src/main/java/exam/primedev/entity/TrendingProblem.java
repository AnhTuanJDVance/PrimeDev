package exam.primedev.entity;

import java.time.LocalDateTime;
import jakarta.persistence.*;

@Entity
@Table(name = "trending_problems")
public class TrendingProblem {

    @Id
    @Column(name = "problem_id")
    private Long problemId;

    @Column(name = "trend_score", nullable = false)
    private Float trendScore;

    @Column(name = "updated_at", columnDefinition = "DATETIME DEFAULT CURRENT_TIMESTAMP")
    private LocalDateTime updatedAt;

    @ManyToOne
    @JoinColumn(name = "problem_id", referencedColumnName = "id", insertable = false, updatable = false)
    private Problem problem;

    // Getters & Setters
    public Long getProblemId() {
        return problemId;
    }

    public void setProblemId(Long problemId) {
        this.problemId = problemId;
    }

    public Float getTrendScore() {
        return trendScore;
    }

    public void setTrendScore(Float trendScore) {
        this.trendScore = trendScore;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Problem getProblem() {
        return problem;
    }

    public void setProblem(Problem problem) {
        this.problem = problem;
    }
}
