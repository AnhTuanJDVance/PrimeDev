package exam.primedev.entity;

import java.util.List;

public class PythonRequest {
    public String code; // Mã Python
    public int language;
    public List<TestCasess> testCases; // Danh sách các test case
    
    // Getters và setters

    public String getCode() {
        return code;
    }

    public int getlanguage() {
        return language;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public List<TestCasess> getTestCases() {
        return testCases;
    }

    public void setTestCases(List<TestCasess> testCases) {
        this.testCases = testCases;
    }
}
