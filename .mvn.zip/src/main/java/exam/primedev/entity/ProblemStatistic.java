package exam.primedev.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "problem_statistics")
public class ProblemStatistic {

    @Id
    @Column(name = "problem_id")
    private Long problemId;

    @Column(name = "total_submissions")
    private Integer totalSubmissions = 0;

    @Column(name = "total_accepted")
    private Integer totalAccepted = 0;

    @Column(name = "average_runtime")
    private Float averageRuntime;

    // Getters & Setters
    public Long getProblemId() {
        return problemId;
    }

    public void setProblemId(Long problemId) {
        this.problemId = problemId;
    }

    public Integer getTotalSubmissions() {
        return totalSubmissions;
    }

    public void setTotalSubmissions(Integer totalSubmissions) {
        this.totalSubmissions = totalSubmissions;
    }

    public Integer getTotalAccepted() {
        return totalAccepted;
    }

    public void setTotalAccepted(Integer totalAccepted) {
        this.totalAccepted = totalAccepted;
    }

    public Float getAverageRuntime() {
        return averageRuntime;
    }

    public void setAverageRuntime(Float averageRuntime) {
        this.averageRuntime = averageRuntime;
    }
}
