package exam.primedev.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "editor_settings")
public class EditorSettings {

    @Id
    @OneToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private User user;

    @Column(name = "theme", nullable = false, length = 50)
    private String theme;

    @Column(name = "themecode", nullable = false, length = 50)
    private String themeCode;

    @Column(name = "font_size", nullable = false)
    private Integer fontSize;

    @Column(name = "tab_size", nullable = false)
    private Integer tabSize;

    // Getters & Setters
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    public String getThemeCode() {
        return themeCode;
    }

    public void setThemeCode(String themeCode) {
        this.themeCode = themeCode;
    }

    public Integer getFontSize() {
        return fontSize;
    }

    public void setFontSize(Integer fontSize) {
        this.fontSize = fontSize;
    }

    public Integer getTabSize() {
        return tabSize;
    }

    public void setTabSize(Integer tabSize) {
        this.tabSize = tabSize;
    }
}
