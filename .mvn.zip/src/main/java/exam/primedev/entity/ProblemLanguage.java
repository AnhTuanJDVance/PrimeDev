package exam.primedev.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "problem_languages")
public class ProblemLanguage {

    @ManyToOne
    @JoinColumn(name = "problem_id", nullable = false)
    private Problem problem;

    @ManyToOne
    @JoinColumn(name = "language_id", nullable = false)
    private Language language;

    // Getters & Setters
    public Problem getProblem() {
        return problem;
    }

    public void setProblem(Problem problem) {
        this.problem = problem;
    }

    public Language getLanguage() {
        return language;
    }

    public void setLanguage(Language language) {
        this.language = language;
    }
}
