package exam.primedev.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import exam.primedev.entity.Book;

public interface BookRepository extends JpaRepository<Book, Long> {

}
